#!/bin/sh
set -e

SERVICE=aws-iot-device-client
USER=root
GROUP=root
TEMPLATE=/etc/aws-iot-device-client/aws-iot-device-client.conf
OUT_DIR=/run/${SERVICE}
OUT=${OUT_DIR}/aws-iot-device-client.conf
AWS_CONFIG_FILE=/opt/aws-iot-device-client/aws-iot-config.env
CLAIM_CERTS_DIR=/opt/aws-iot-device-client/certs
IDENTITY_DIR=/opt/aws-iot-device-client/identity
MQTT_HOST=127.0.0.1
MQTT_PORT=1883
MQTT_TOPIC="status/gate/hardware"

install -d -m 0750 -o ${USER} -g ${GROUP} ${OUT_DIR}

if [ ! -f "${TEMPLATE}" ]; then
  echo "Template config not found: ${TEMPLATE}" >&2
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "jq is required to generate config" >&2
  exit 1
fi

if [ -f "${AWS_CONFIG_FILE}" ]; then
  while IFS= read -r line; do
    case "$line" in
      ''|'#'*) continue ;;
      *=*) export "$line" ;;
    esac
  done < "${AWS_CONFIG_FILE}"
fi

# Read serial number from MQTT topic
echo "Reading serial number from MQTT topic: ${MQTT_TOPIC}"
SERIAL_NUMBER=$(timeout 10 mosquitto_sub -h ${MQTT_HOST} -p ${MQTT_PORT} -t ${MQTT_TOPIC} -C 1 2>/dev/null | jq -r '.sbc.serialNumber // empty' 2>/dev/null || echo "")

if [ -z "${SERIAL_NUMBER}" ]; then
  echo "Failed to read serial number from MQTT topic ${MQTT_TOPIC}" >&2
  exit 1
fi

echo "AWS_IOT_ENDPOINT=${AWS_IOT_ENDPOINT:-<not set>}"
echo "FLEET_PROVISIONING_TEMPLATE=${FLEET_PROVISIONING_TEMPLATE:-<not set>}"
echo "SERIAL_NUMBER=${SERIAL_NUMBER}"

# Check for certificates in multiple locations
# First check where AWS IoT Device Client actually stores them
AWS_CLIENT_KEYS_DIR="/root/.aws-iot-device-client/keys"
CERT_PATH="${CLAIM_CERTS_DIR}/claim-certificate.pem.crt"
KEY_PATH="${CLAIM_CERTS_DIR}/claim-private.pem.key"

if [ -f "${AWS_CLIENT_KEYS_DIR}/active-private.pem.key" ] && [ -f "${AWS_CLIENT_KEYS_DIR}/active-certificate.pem.crt" ]; then
  CERT_PATH="${AWS_CLIENT_KEYS_DIR}/active-certificate.pem.crt"
  KEY_PATH="${AWS_CLIENT_KEYS_DIR}/active-private.pem.key"
  echo "Using identity certificates from ${AWS_CLIENT_KEYS_DIR}"
elif [ -f "${IDENTITY_DIR}/active-private.pem.key" ] && [ -f "${IDENTITY_DIR}/active-certificate.pem.crt" ]; then
  CERT_PATH="${IDENTITY_DIR}/active-certificate.pem.crt"
  KEY_PATH="${IDENTITY_DIR}/active-private.pem.key"
  echo "Using identity certificates from ${IDENTITY_DIR}"
fi

jq --arg endpoint "${AWS_IOT_ENDPOINT:-}" \
   --arg serial_number "${SERIAL_NUMBER}" \
   --arg template_name "${FLEET_PROVISIONING_TEMPLATE:-}" \
   --arg cert "${CERT_PATH}" \
   --arg key "${KEY_PATH}" '
  .cert = $cert
| .key = $key
| (if $endpoint != "" then .endpoint = $endpoint else . end)
| (if $serial_number != "" then .["thing-name"] = $serial_number else . end)
| (if $template_name != "" then .["fleet-provisioning"]["template-name"] = $template_name else . end)
| (if $serial_number != "" then
    .["fleet-provisioning"]["template-parameters"] = (
      "{\"serialNumber\": \"" + $serial_number + "\"}" )
    else . end)
' "${TEMPLATE}" > "${OUT}.tmp"

chown ${USER}:${GROUP} "${OUT}.tmp"
chmod 0640 "${OUT}.tmp"
mv "${OUT}.tmp" "${OUT}"
