#!/bin/sh
set -e

# This wrapper script runs the prerequisite checks, config generation,
# and then starts the actual AWS IoT Device Client.
# Running everything in ExecStart (not ExecStartPre) ensures systemctl start
# returns immediately without blocking.

/usr/lib/aws-iot-device-client/wait-for-prerequisites.sh
/usr/lib/aws-iot-device-client/gen-config.sh
exec /usr/sbin/aws-iot-device-client --config-file /run/aws-iot-device-client/aws-iot-device-client.conf
