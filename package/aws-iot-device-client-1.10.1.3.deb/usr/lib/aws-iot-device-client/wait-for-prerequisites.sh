#!/bin/sh
set -e

SERVICE=aws-iot-device-client
AWS_CONFIG_FILE=/opt/aws-iot-device-client/aws-iot-config.env
CLAIM_CERTS_DIR=/opt/aws-iot-device-client/certs
IDENTITY_DIR=/opt/aws-iot-device-client/identity
CHECK_INTERVAL=30
MQTT_HOST=127.0.0.1
MQTT_PORT=1883
MQTT_TOPIC="status/gate/hardware"
ROUTES_FILE="/opt/aws-iot-device-client/gate-local-mqtt-routes.json"
DMS_TOOLS_DIR="/opt/fgate/tools/dms"
JOBS_DIR="/etc/aws-iot-device-client/jobs"

echo "[$SERVICE] Checking for required files..."

# Copy job handler scripts from DMS tools directory if they exist
if [ -d "${DMS_TOOLS_DIR}" ]; then
  echo "[$SERVICE] Copying job handlers from ${DMS_TOOLS_DIR}..."
  
  if [ -f "${DMS_TOOLS_DIR}/softwareupdate.sh" ]; then
    cp "${DMS_TOOLS_DIR}/softwareupdate.sh" "${JOBS_DIR}/softwareupdate.sh"
    # Fix line endings (convert CRLF to LF) in case files were edited on Windows
    sed -i 's/\r$//' "${JOBS_DIR}/softwareupdate.sh"
    echo "[$SERVICE] Copied: softwareupdate.sh"
  else
    echo "[$SERVICE] Warning: softwareupdate.sh not found in ${DMS_TOOLS_DIR}"
  fi
  
  if [ -f "${DMS_TOOLS_DIR}/logdownload.sh" ]; then
    cp "${DMS_TOOLS_DIR}/logdownload.sh" "${JOBS_DIR}/logdownload.sh"
    # Fix line endings (convert CRLF to LF) in case files were edited on Windows
    sed -i 's/\r$//' "${JOBS_DIR}/logdownload.sh"
    echo "[$SERVICE] Copied: logdownload.sh"
  else
    echo "[$SERVICE] Warning: logdownload.sh not found in ${DMS_TOOLS_DIR}"
  fi
  
  # Fix line endings for all shell scripts in jobs directory
  echo "[$SERVICE] Fixing line endings for all scripts in ${JOBS_DIR}..."
  find "${JOBS_DIR}" -type f -name "*.sh" -exec sed -i 's/\r$//' {} \;
  
  # Make all files in jobs directory executable
  echo "[$SERVICE] Making all files in ${JOBS_DIR} executable..."
  chmod +x "${JOBS_DIR}"/*
  echo "[$SERVICE] All job handler scripts are now executable"
else
  echo "[$SERVICE] Warning: DMS tools directory not found at ${DMS_TOOLS_DIR}"
fi

elapsed=0
while true; do
  # Check for config file and load environment variables
  if [ ! -f "${AWS_CONFIG_FILE}" ]; then
    echo "[$SERVICE] Waiting for config file: ${AWS_CONFIG_FILE} (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi
  
  # Load AWS config environment variables
  while IFS= read -r line; do
    case "$line" in
      ''|'#'*) continue ;;
      *=*) export "$line" ;;
    esac
  done < "${AWS_CONFIG_FILE}"

  # Check for routes file
  if [ ! -f "${ROUTES_FILE}" ]; then
    echo "[$SERVICE] Waiting for routes file: ${ROUTES_FILE} (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi

  # Check for claim certificates (identity certs are created automatically after provisioning)
  if [ ! -f "${CLAIM_CERTS_DIR}/claim-certificate.pem.crt" ] || \
     [ ! -f "${CLAIM_CERTS_DIR}/claim-private.pem.key" ] || \
     [ ! -f "${CLAIM_CERTS_DIR}/AmazonRootCA1.pem" ]; then
    echo "[$SERVICE] Waiting for claim certificates in ${CLAIM_CERTS_DIR} (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi

  # Check if mosquitto is available
  if ! command -v mosquitto_sub >/dev/null 2>&1; then
    echo "[$SERVICE] mosquitto_sub not found. Waiting... (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi

  # Check if mosquitto broker is running (using timeout and mosquitto_sub)
  if ! timeout 5 mosquitto_sub -h ${MQTT_HOST} -p ${MQTT_PORT} -t '$SYS/broker/version' -C 1 >/dev/null 2>&1; then
    echo "[$SERVICE] Local MQTT broker not available at ${MQTT_HOST}:${MQTT_PORT}. Waiting... (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi

  # Try to read serial number from MQTT topic
  echo "[$SERVICE] Attempting to read serial number from MQTT topic: ${MQTT_TOPIC}"
  SERIAL_NUMBER=$(timeout 10 mosquitto_sub -h ${MQTT_HOST} -p ${MQTT_PORT} -t ${MQTT_TOPIC} -C 1 2>/dev/null | jq -r '.sbc.serialNumber // empty' 2>/dev/null || echo "")
  
  if [ -z "${SERIAL_NUMBER}" ]; then
    echo "[$SERVICE] Serial number not available from ${MQTT_TOPIC}. Waiting... (waited ${elapsed}s)"
    sleep $CHECK_INTERVAL
    elapsed=$((elapsed + CHECK_INTERVAL))
    continue
  fi

  echo "[$SERVICE] Serial number retrieved: ${SERIAL_NUMBER}"
  echo "[$SERVICE] All required files and data found."
  
  # Check if endpoint has changed and re-registration is needed
  RUNTIME_CONFIG="$HOME/.aws-iot-device-client/aws-iot-device-client-runtime.conf"
  TEMPLATE_CONFIG="/etc/aws-iot-device-client/aws-iot-device-client.conf"
  
  if [ -f "${RUNTIME_CONFIG}" ]; then
    echo "[$SERVICE] Found existing runtime config. Checking if endpoint has changed..."
    
    # Extract new endpoint from env file (already loaded)
    NEW_ENDPOINT="${AWS_IOT_ENDPOINT:-}"
    
    # Extract current endpoint from template config
    CURRENT_ENDPOINT=$(jq -r '.endpoint // empty' "${TEMPLATE_CONFIG}" 2>/dev/null || echo "")
    
    echo "[$SERVICE] Current endpoint in config: ${CURRENT_ENDPOINT}"
    echo "[$SERVICE] New endpoint from env: ${NEW_ENDPOINT}"
    
    if [ -n "${NEW_ENDPOINT}" ] && [ -n "${CURRENT_ENDPOINT}" ] && [ "${NEW_ENDPOINT}" != "${CURRENT_ENDPOINT}" ]; then
      echo "[$SERVICE] *** ENDPOINT CHANGE DETECTED ***"
      echo "[$SERVICE] Old endpoint: ${CURRENT_ENDPOINT}"
      echo "[$SERVICE] New endpoint: ${NEW_ENDPOINT}"
      echo "[$SERVICE] Triggering re-registration..."
      
      # Clean up old identity certificates and runtime config
      echo "[$SERVICE] Removing old runtime config..."
      rm -f "${RUNTIME_CONFIG}"
      
      echo "[$SERVICE] Removing old identity certificates..."
      rm -rf "$HOME/.aws-iot-device-client/keys/"
      rm -rf /root/.aws-iot-device-client/keys/
      rm -rf "${IDENTITY_DIR}"
      
      echo "[$SERVICE] Updating template config with new endpoint..."
      # Update template config with new endpoint
      jq --arg endpoint "${NEW_ENDPOINT}" '.endpoint = $endpoint' "${TEMPLATE_CONFIG}" > "${TEMPLATE_CONFIG}.tmp"
      mv "${TEMPLATE_CONFIG}.tmp" "${TEMPLATE_CONFIG}"
      chmod 0640 "${TEMPLATE_CONFIG}"
      
      echo "[$SERVICE] Re-registration cleanup complete. Device will re-register with new endpoint."
    else
      echo "[$SERVICE] No endpoint change detected. Using existing identity certificates."
    fi
  else
    echo "[$SERVICE] No runtime config found. This is first-time registration."
    
    # Update template config with endpoint from env if provided
    if [ -n "${AWS_IOT_ENDPOINT:-}" ]; then
      echo "[$SERVICE] Updating template config with endpoint from env..."
      jq --arg endpoint "${AWS_IOT_ENDPOINT}" '.endpoint = $endpoint' "${TEMPLATE_CONFIG}" > "${TEMPLATE_CONFIG}.tmp"
      mv "${TEMPLATE_CONFIG}.tmp" "${TEMPLATE_CONFIG}"
      chmod 0640 "${TEMPLATE_CONFIG}"
    fi
  fi
  
  # Set permissions on claim certificates (especially important after cert replacement)
  echo "[$SERVICE] Setting permissions on claim certificates..."
  chmod 0700 "${CLAIM_CERTS_DIR}" 2>/dev/null || true
  chmod 0600 "${CLAIM_CERTS_DIR}/claim-private.pem.key" 2>/dev/null || true
  chmod 0644 "${CLAIM_CERTS_DIR}/claim-certificate.pem.crt" 2>/dev/null || true
  chmod 0644 "${CLAIM_CERTS_DIR}/AmazonRootCA1.pem" 2>/dev/null || true
  
  # Set all required permissions per AWS IoT Device Client documentation
  # https://github.com/awslabs/aws-iot-device-client/blob/main/docs/PERMISSIONS.md
  echo "[$SERVICE] Setting all required file and directory permissions..."
  
  # Certificate directories and files
  chmod 0700 "${IDENTITY_DIR}" 2>/dev/null || true
  
  # Identity certificates (if they exist)
  if [ -f "${IDENTITY_DIR}/active-private.pem.key" ]; then
    chmod 0600 "${IDENTITY_DIR}/active-private.pem.key" 2>/dev/null || true
  fi
  if [ -f "${IDENTITY_DIR}/active-certificate.pem.crt" ]; then
    chmod 0644 "${IDENTITY_DIR}/active-certificate.pem.crt" 2>/dev/null || true
  fi
  
  # AWS IoT Device Client keys directory (created after fleet provisioning)
  AWS_CLIENT_KEYS_DIR="/root/.aws-iot-device-client/keys"
  if [ -d "${AWS_CLIENT_KEYS_DIR}" ]; then
    chmod 0700 "${AWS_CLIENT_KEYS_DIR}" 2>/dev/null || true
    if [ -f "${AWS_CLIENT_KEYS_DIR}/active-private.pem.key" ]; then
      chmod 0600 "${AWS_CLIENT_KEYS_DIR}/active-private.pem.key" 2>/dev/null || true
    fi
    if [ -f "${AWS_CLIENT_KEYS_DIR}/active-certificate.pem.crt" ]; then
      chmod 0644 "${AWS_CLIENT_KEYS_DIR}/active-certificate.pem.crt" 2>/dev/null || true
    fi
  fi
  
  # Config directory and files
  chmod 0745 /etc/aws-iot-device-client 2>/dev/null || true
  if [ -f "${TEMPLATE_CONFIG}" ]; then
    chmod 0640 "${TEMPLATE_CONFIG}" 2>/dev/null || true
  fi
  
  # Job handlers directory and files
  chmod 0700 "${JOBS_DIR}" 2>/dev/null || true
  find "${JOBS_DIR}" -type f -exec chmod 0700 {} \; 2>/dev/null || true
  
  # Log directory and files
  LOG_DIR=/var/log/aws-iot-device-client
  chmod 0745 "${LOG_DIR}" 2>/dev/null || true
  if [ -f "${LOG_DIR}/aws-iot-device-client.log" ]; then
    chmod 0600 "${LOG_DIR}/aws-iot-device-client.log" 2>/dev/null || true
  fi
  
  # Routes file
  if [ -f "${ROUTES_FILE}" ]; then
    chmod 0644 "${ROUTES_FILE}" 2>/dev/null || true
  fi
  
  # Config file (env)
  if [ -f "${AWS_CONFIG_FILE}" ]; then
    chmod 0640 "${AWS_CONFIG_FILE}" 2>/dev/null || true
  fi
  
  echo "[$SERVICE] All permissions set correctly. Starting service..."
  exit 0
done
